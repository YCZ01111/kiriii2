#include <time.h>
#include "Timer.h"
#include <limits>

NS_KRMOVIE_BEGIN
const unsigned int Timer::InfiniteValue = std::numeric_limits<unsigned int>::max();
NS_KRMOVIE_END
