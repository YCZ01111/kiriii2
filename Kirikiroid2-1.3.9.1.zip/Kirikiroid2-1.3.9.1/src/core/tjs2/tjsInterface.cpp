//---------------------------------------------------------------------------
/*
	TJS2 Script Engine
	Copyright (C) 2000 W.Dee <dee@kikyou.info> and contributors

	See details of license at "license.txt"
*/
//---------------------------------------------------------------------------
// iTJSDispatch2 interface definition
//---------------------------------------------------------------------------

#include "tjsCommHead.h"

#include "tjsInterface.h"

namespace TJS
{
//---------------------------------------------------------------------------


//---------------------------------------------------------------------------
} // namespace TJS


