#include "tjsCommHead.h"
#include "HintWindow.h"
HDWP TVPShowHintWindowTop(HDWP hdwp)
{
	return NULL;
}
