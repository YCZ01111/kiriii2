//---------------------------------------------------------------------------
/*
	TVP2 ( T Visual Presenter 2 )  A script authoring tool
	Copyright (C) 2000-2007 W.Dee <dee@kikyou.info> and contributors

	See details of license at "license.txt"
*/
//---------------------------------------------------------------------------
#ifndef OptionsDescH
#define OptionsDescH

extern ttstr TVPGetCommandDesc();

#endif
//---------------------------------------------------------------------------
